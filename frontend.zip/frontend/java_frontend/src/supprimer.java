import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.util.ArrayList;

public class supprimer implements ActionListener{
    JFrame frame=new JFrame() ; 
    JTextField supprimer=new JTextField();
    JLabel supprimer1 =  new JLabel("give the number of the client targeted ") ; 
    JButton OK= new JButton("Ok");
    ArrayList<String> list2=new ArrayList<>();
    ArrayList<String> list3=new ArrayList<>();
    supprimer(ArrayList<String> list,ArrayList<String> list2){
        this.list2=list ;
        this.list3=list2;
        supprimer1.setBounds(100,20,250,35);;
		supprimer1.setFont(new Font(null,Font.ITALIC,13));
        supprimer1.setForeground(Color.black);
        supprimer.setBounds(125,100,50,25);

        OK.setBounds(125,160,200,25);
		OK.setFocusable(false);
		OK.addActionListener(this);


        frame.add(OK);
        frame.add(supprimer1);
        frame.add(supprimer) ; 
        frame.setSize(400, 250);
       
    frame.setLayout(null);
     frame.setVisible(true);
}
    @Override
    public void actionPerformed(ActionEvent e) {
        
		if(e.getSource()==OK ) {
            String index = supprimer.getText();
            int a=Integer.parseInt(index);
            this.list2.remove(a-1);
            this.list3.remove(a-1);
            frame.dispose();
            window window=new window(list2,list3);

			
			
        
        
    }}}
