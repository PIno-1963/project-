public class App {
    public static void main(String[] args) throws Exception {
        logingpage logingpage=new logingpage() ; 
    }
}
