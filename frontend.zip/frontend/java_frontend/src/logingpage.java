import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.imageio.ImageTranscoder;
import javax.swing.*;
import java.util.ArrayList;


public class logingpage implements ActionListener{
       JFrame frame = new JFrame() ; 
       JButton create_account= new JButton("create new account") ; 
       JButton display= new JButton("display") ;
       JTextField nom_field= new JTextField() ;
       JTextField prenom_field= new JTextField() ; 
       JTextField numeros_compt= new JTextField() ;
       JLabel nomLabel= new JLabel("NOM") ; 
       JLabel prenomLabel= new JLabel("PRENOM") ; 
       JLabel numeros_cpt = new JLabel("NUMEROS") ; 
       ArrayList<String> clients_name = new ArrayList<>() ; 
       ArrayList<String> clients_number = new ArrayList<>() ;
       JLabel messageLabel = new JLabel();
       JLabel messageLabel1 = new JLabel();
       
       int cpt=0;

    logingpage(){

      nomLabel.setBounds(50,100,75,25);
      prenomLabel.setBounds(50,150,75,25);
      numeros_cpt.setBounds(50,200,75,25); 

        nom_field.setBounds(125,100,200,25);
		prenom_field.setBounds(125,150,200,25);
        numeros_compt.setBounds(125,200,200,25);

        create_account.setBounds(125,300,200,25);
		create_account.setFocusable(false);
		create_account.addActionListener(this);

        display.setBounds(125,250,200,25);
		display.setFocusable(false);
		display.addActionListener(this);

        messageLabel.setBounds(125,350,250,35);
		messageLabel.setFont(new Font(null,Font.ITALIC,25));

        messageLabel1.setBounds(120,20,250,35);
		messageLabel1.setFont(new Font(null,Font.ITALIC,25));
        messageLabel1.setForeground(Color.black);
		messageLabel1.setText("welcome to our bank");
        

        
        frame.getContentPane().setBackground(new Color(200, 216, 230));
        frame.add(nomLabel);
		frame.add(prenomLabel);
        frame.add(numeros_cpt);
		frame.add(nom_field);
		frame.add(prenom_field);
		frame.add(create_account);
        frame.add(display);
        frame.add(messageLabel);
        frame.add(numeros_compt);
        frame.add(messageLabel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(420,420);
		frame.setLayout(null);
		frame.setVisible(true);
		ImageIcon image=new ImageIcon("1528.png");
        frame.setIconImage(image.getImage());

    }
    
        @Override
	public void actionPerformed(ActionEvent e) {
       
		
		
		if(e.getSource()==create_account  ) {
            String nom = nom_field.getText();
			String prenom = prenom_field.getText();
			String numeros = numeros_compt.getText() ;
			
            
           this.clients_name.add(nom+" "+prenom) ; 
           this.clients_number.add(numeros); 
           cpt++;
        
            nom_field.setText("");
			prenom_field.setText("");
            numeros_compt.setText("");
            }
	
    

    if(e.getSource()==display && cpt>0  ) {
			
            nom_field.setText("");
			prenom_field.setText("");
            numeros_compt.setText("");
           // frame.dispose();
            window window=new window(clients_name,clients_number);
	
    }
    if(e.getSource()==display && cpt<=0 ){
        messageLabel.setForeground(Color.red);
				messageLabel.setText("need more");
    }


}}

