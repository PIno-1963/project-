import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.util.ArrayList;


public class window implements  ActionListener {
    JFrame frame = new JFrame();
    JPanel panel = new JPanel();
    JButton supprimer= new JButton("supprimmer");
    JButton ajouter = new JButton("ajouter");
    ArrayList<String> list=new ArrayList<>(); 
    ArrayList<String> list2=new ArrayList<>();
    
    window(ArrayList<String> names,ArrayList<String> numbers){
        this.list=names; 
        this.list2=numbers;
        // Set the layout of the panel to a BoxLayout
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        for(int i=0;i<names.size();i++){
            panel.add(new JLabel((i+1)+"--"+ names.get(i)+"              "+numbers.get(i)));
            panel.setBackground(new Color(173, 216, 230));
        }

        // Set the layout of the frame to a BorderLayout
        frame.setLayout(new BorderLayout());

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(ajouter);
        buttonPanel.add(supprimer);
        buttonPanel.setBackground(new Color(173, 216, 230));
        supprimer.addActionListener(this);
        ajouter.addActionListener(this);
        // Add the panel and buttonPanel to the frame
        frame.add(panel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);
  
        frame.getContentPane().setBackground(new Color(173, 216, 230));
        supprimer.setFocusable(false); 
        ajouter.setFocusable(false); 

        // Set the size and layout of the frame
        frame.setSize(420, 420);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if(e.getSource()==ajouter ){
            frame.dispose();
            ajouter page=new ajouter(list,list2);
        }
        if(e.getSource()==supprimer ){
            frame.dispose();
            supprimer page2=new supprimer(list,list2) ;
            

            
        }
        
    }
}
