import java.util.ArrayList;
import java.util.Scanner; 
public class client {
    String nom ; 
    String prenom ; 
    String numeros_cpt ; 
    public ArrayList<String> clients_name = new ArrayList<>();
    public ArrayList<String> clients_numeros = new ArrayList<>();
    public void addclients(){
        Scanner sc=new Scanner(System.in) ;
        System.out.print("-->> enter the  client first name : ") ; 
        this.nom=sc.next() ; 
        System.out.print("-->> enter the  client last name : ") ; 
        this.prenom=sc.next() ;
        System.out.print("enter the  client account number (le numeros doit contenir 11 caractere) : ") ; 
        this.numeros_cpt=sc.next() ;
         
        while(this.numeros_cpt.length() < 12){
            System.out.print("give another compositon  : ") ; 
            this.numeros_cpt=sc.next() ;  
        }
        
        clients_name.add(nom +" "+ prenom);
        clients_numeros.add(this.numeros_cpt);
        
    }
    public void afficher_list(){
        System.out.println ("\n");
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
        System.out.println ("\t\t        | liste des participants |\n");
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
        System.out.println("|"+ "Nom | Prenom" +"|" +"\t"+"\t"+ "numeros du compt" + "\n") ; 
        for(int i=0 ;i<clients_name.size();i++) {
            System.out.println((i+1)+"--" + clients_name.get(i) +"\t"+clients_numeros.get(i) + "\n") ; 
        }
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n\n");
    }
    public void modifier(){
        Scanner sc4=new Scanner(System.in);
        Scanner sc5=new Scanner(System.in);
        Scanner sc6=new Scanner(System.in);
        System.out.println("give the number of the client targeted  :  ") ; 
        int index1 = sc4.nextInt() ; 
        System.out.println("(1) - modifier le nom et prenom") ; 
        System.out.println("(2) - modifier le numeros du compt") ; 
        System.out.println("give the number of the modification :  ") ;
        int index2 = sc4.nextInt() ;
        String new_name ; 
        String new_name2;

        if (index2==1){
                  System.out.print("give the new name :  ") ;
                  new_name=sc5.nextLine() ; 
                  System.out.print("give the last name : ") ; 
                  new_name2=sc6.nextLine();
                  clients_name.set(index1-1,new_name+" "+new_name2) ;
              }
              
            else{
            System.out.println("give the new account_number :") ;
            String new_accont_number=sc4.nextLine() ; 
            clients_numeros.set(index1-1,new_accont_number) ;
            }  // code block
              }
          
          
          


        

        

    public void remove(){
        Scanner sc4=new Scanner(System.in); 
        System.out.println("give the number of the client targeted  :  ") ; 
        int index1 = sc4.nextInt() ; 
        clients_name.remove(index1-1); 
        clients_numeros.remove(index1-1);
        
      


        

        
    }
     

    public void menu(){
        System.out.println("(1) - Ajouter un nouveau client") ; 
        System.out.println("(2) - Supprimer un client") ; 
        System.out.println("(3) - Modifier les information d'un client"); 
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££");
        System.out.println ("\t\t        | entrer un numeros |");
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
        Scanner sc3=new Scanner(System.in) ;
        int i =sc3.nextInt(); 
        
        switch(i) {
            case 1:
              addclients();
              break;
            case 2:
                remove();
              // code block
              break;
            case 3:
              modifier();
              break;
            default:
              // code block
          }
    }
        
}


