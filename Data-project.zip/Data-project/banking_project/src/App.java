import java.util.Scanner ; 

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("\n\n\n\n\n");
        System.out.println("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
        System.out.println("\n\t\t\t        $-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$");
        System.out.println("\n\t\t\t        $                  WELCOME                  $");
        System.out.println("\n\t\t\t        $                    TO                     $");
        System.out.println("\n\t\t\t        $              OUR BANK AGENCY              $");
        System.out.println("\n\t\t\t        $                                           $");
        System.out.println("\n\t\t\t        $-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$-$");
        System.out.println("\n\t\t\t  **-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**\n");
        System.out.println("\n");
       System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
       System.out.println ("\t\t        | Create new accounte |\n");
       System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
       client client1=new client()  ; 
       System.out.println("--->> veullez entrer 5 clients nouveau");
       for(int i=0;i<5 ; i++){
     System.out.println("----client "+(i+1) +"---") ;
        client1.addclients();}
       
        int prss1;
        do {
            client1.afficher_list();
            client1.menu(); 
            client1.afficher_list();
             System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
             System.out.println ("\t\t        | presse 1 to continue or 0 to finish |\n");
             System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
             Scanner sc=new Scanner(System.in); 
             int prss=sc.nextInt();
             prss1=prss ; 

            
        } while (prss1==1);
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
        System.out.println ("\t\t        | goodby |\n");
        System.out.println ("\t\t£££££££££££££££££££££££££££££££££££££££££\n");
    
}}
